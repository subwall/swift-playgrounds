//: Playground - noun: a place where people can play

import Cocoa

// Return a dictionary of roof panel lengths and quantities, given the panel width and three sides of a roof facet with a triangular end.
//
// Roof Shape Defined in This Function
//         |width|
//
//              /|
//             / |
//            /  |
//           /   |
//          /    |
//         |     |
//         |     |
//         |     |
//  short  |     |  long
//         |     |
//         |     |
//         |     |
//         |_|_|_|
//
//        panelWidth
//

var panelLengths = [Double] ()
var counts = [Double:Int] ()

// Take all required dimensions in inches
func panelLengthsForAGivenArea(withShortestSide short: Double, withLongestSide long: Double, withOverallWidth width: Double, withTotalPerPanelCoverage panelWidth: Double) -> [Double]{
    // Calculate height of triangle "Side A" (known)
    let height = long - short
    // Define base of triangle "Side B" (known)
    var base = width
    // Find base angle of triangle (unknown)
    let theta = findFirstAngle(givenBase: width, givenHeight: height)
    // Specify length to add to each side A calculation to get full panel length
    let adder = long - height
    // Figure out how many panels are needed to cover the given roof width
    let panelCount = Int((width / panelWidth) + 1)
    // For each panel, call the findHeight function to determine
    // the length of "Side C" of the triangle.
    // Add the remaining panel length, and subtract base width "Side B" by one panel.
    for _ in 1 ... panelCount {
        panelLengths.append(findHeight(givenBase: base, givenAngleA: theta) + adder)
        base -= panelWidth
    }
    return panelLengths
}

// Take the parameters given and find the triangle base angle to be used in further calculations.
func findFirstAngle(givenBase base: Double, givenHeight height: Double) -> Double {
    return atan(height / base)
    // let angleA = atan(height / base)
    // return angleA
}

// Find "Side B" of the triangle at any given base width, determined
// by which panel is being figured.
func findHeight(givenBase base: Double, givenAngleA angle: Double) -> Double {
    return base * (tan(angle))
    // let panelHeight = base * (tan(angle))
    // return panelHeight
}


// Roof Areas A, B, E, F (30 each) This roof facet is rectangular
for _ in 1...120 {
    panelLengths.append(669)
}

// Roof Areas C, D (24 each) This roof facet is rectangular
for _ in 1...48 {
    panelLengths.append(780)
}

// Roof Area G
panelLengthsForAGivenArea(withShortestSide: 381, withLongestSide: 585, withOverallWidth: 222, withTotalPerPanelCoverage: 17.5)

// Roof Area H
panelLengthsForAGivenArea(withShortestSide: 316, withLongestSide: 513, withOverallWidth: 172, withTotalPerPanelCoverage: 17.5)

// Roof Area I
panelLengthsForAGivenArea(withShortestSide: 316, withLongestSide: 513, withOverallWidth: 172, withTotalPerPanelCoverage: 17.5)

// Roof Area J
panelLengthsForAGivenArea(withShortestSide: 381, withLongestSide: 585, withOverallWidth: 222, withTotalPerPanelCoverage: 17.5)

// Roof Area K
panelLengthsForAGivenArea(withShortestSide: 480, withLongestSide: 585, withOverallWidth: 96, withTotalPerPanelCoverage: 17.5)

// Roof Area L
panelLengthsForAGivenArea(withShortestSide: 317, withLongestSide: 612, withOverallWidth: 289.5, withTotalPerPanelCoverage: 17.5)

// Roof Area M
panelLengthsForAGivenArea(withShortestSide: 317, withLongestSide: 612, withOverallWidth: 289.5, withTotalPerPanelCoverage: 17.5)

// Roof Area N
panelLengthsForAGivenArea(withShortestSide: 480, withLongestSide: 585, withOverallWidth: 96, withTotalPerPanelCoverage: 17.5)

// *** A test for a pure triangular roof facet
// Test Roof Section
// panelLengthsForAGivenArea(withShortestSide: 0, withLongestSide: 144, withOverallWidth: 144, withTotalPerPanelCoverage: 12)
// ***

// Print total number of panels
print("The total number of panels to be run is \(panelLengths.count)")
print("")

// Convert panel lengths to feet and organize using map
let panelLengthsInFeet = panelLengths.map {
    (panels: Double) -> Double in
    // let roundedPercentage = Double(round(100 * currentPercentage) / 100) // *** This didn't work as expected ***
    return panels / 12
}

// Calculate the raw coil length needed
var totalCoilLengthNeeded = 0.0
for i in panelLengthsInFeet {
    totalCoilLengthNeeded += i
}

// Each coil is 1,200 Lin. Ft.
let totalCoils = totalCoilLengthNeeded / 1200

// Print some basic info
print("The total LF of panels to be rolled is: \(totalCoilLengthNeeded)")
print("")
print("The total number of 1200LF coils needed is: \(totalCoils)")
print("")

// I made this variable, but I'm not sure why. Fairly certain it effects nothing.
// var lengthCounts = 0

// Create an array of length counts
for item in panelLengthsInFeet {
    if let value = counts[item] {
        counts[item] = value + 1
    } else {
        counts[item] = 1
    }
}

for key in counts {
    print(key)
}

print("")

// I needed to print the unique lengths just to save myself time manually entering
// the lengths into excel
print("Unique Lengths: ")
let uniqueLengths = Array(counts.keys)
print(uniqueLengths.sorted())
