//: Playground - noun: a place where people can play

import Cocoa

protocol TabularDataSource {
    var numberOfRows: Int { get }
    var numberOfColumns: Int { get }
    
    func label(forColumn column: Int) -> String
    func itemFor(row: Int, column: Int) -> String
}

func printTable(_ dataSource: TabularDataSource & CustomStringConvertible) {
    print("Table: \(dataSource.description)")
    
    // Create an array containing one value for each column, and record the count of the longest table body value in that column
    var bodyColumnWidths = [Int](repeatElement(0, count: dataSource.numberOfColumns))
    for i in 0 ..< dataSource.numberOfRows {
        for j in 0 ..< dataSource.numberOfColumns {
            let columnListingForRow = dataSource.itemFor(row: i, column: j)
            if columnListingForRow.count > bodyColumnWidths[j] {
                bodyColumnWidths[j] = columnListingForRow.count
            }
        }
    }
    
    // Create an array containing one value for each title, and record the count of each
    var tableColumnWidths = [Int](repeatElement(0, count: dataSource.numberOfColumns))
    for i in 0 ..< dataSource.numberOfColumns {
        let columnListingForTitleRow = dataSource.label(forColumn: i)
        if columnListingForTitleRow.count > tableColumnWidths[i] { // This is probably unnecessary for the title row
            tableColumnWidths[i] = columnListingForTitleRow.count
        }
    }
    
    // Create a final array of column widths, to be used throughout the table
    var finalColumnWidths = [Int](repeatElement(0, count: dataSource.numberOfColumns))
    for (index, value) in tableColumnWidths.enumerated() {
        if value > bodyColumnWidths[index] {
            finalColumnWidths[index] = value
        } else {
            finalColumnWidths[index] = bodyColumnWidths[index]
        }
    }
    
    // Create a variable to determine how much padding, if any is needed for each table element
    var additionalColumnPaddingNeeded = 0
    
    // Create first row containing column headers
    var firstRow = "|"
    
    for i in 0 ..< dataSource.numberOfColumns {
        let columnLabel = dataSource.label(forColumn: i)
        additionalColumnPaddingNeeded = (finalColumnWidths[i] - columnLabel.count)
        let additionalPadding = repeatElement(" ", count: additionalColumnPaddingNeeded).joined(separator: "")
        let columnHeader = " \(additionalPadding)\(columnLabel) |"
        firstRow += columnHeader
    }
    print(firstRow)
    
    // Create the body portion of the table
    for i in 0 ..< dataSource.numberOfRows {
        // Start the output string
        var out = "|"
        // Append each item in this row to the string
        for j in 0 ..< dataSource.numberOfColumns {
            let item = dataSource.itemFor(row: i, column: j)
            additionalColumnPaddingNeeded = (finalColumnWidths[j] - item.count)
            let additionalPadding = repeatElement(" ", count: additionalColumnPaddingNeeded).joined(separator: "")
            let bodyOutput = " \(additionalPadding)\(item) |"
            out += bodyOutput
        }
    
        // Done - print it!
        print(out)
    }
}

struct Person {
    let name: String
    let age: Int
    let yearsOfExperience: Int
}

struct Department: TabularDataSource, CustomStringConvertible {
    let name: String
    var people = [Person]()
    
    var description: String {
        return "Department (\(name))"
    }
    
    init (name: String) {
        self.name = name
    }
    
    mutating func add(_ person: Person) {
        people.append(person)
    }
    
    var numberOfRows: Int {
        return people.count
    }
    
    var numberOfColumns: Int {
        return 3
    }
    
    func label(forColumn column: Int) -> String {
        switch column {
        case 0: return "Employee Name"
        case 1: return "Age"
        case 2: return "Years of Experience"
        default: fatalError("Invalid column!")
        }
    }
    
    func itemFor(row: Int, column: Int) -> String {
        let person = people[row]
        switch column {
        case 0: return person.name
        case 1: return String(person.age)
        case 2: return String(person.yearsOfExperience)
        default: fatalError("Invalid column!")
        }
    }
}



struct Book {
    let title: String
    let author: String
    let avgAmazonRating: Double
    let isbn: String
}

struct BookCollection: TabularDataSource, CustomStringConvertible {
    let title: String
    var books = [Book]()
    
    var description: String {
        return "\(title)"
    }
    
    init (title: String) {
        self.title = title
    }
    
    mutating func add(_ book: Book) {
        books.append(book)
    }
    
    var numberOfRows: Int {
        return books.count
    }
    
    var numberOfColumns: Int {
        return 4
    }
    
    func label(forColumn column: Int) -> String {
        switch column {
        case 0: return "Book Title"
        case 1: return "Author(s)"
        case 2: return "Average Rating"
        case 3: return "ISBN"
        default: fatalError("Invalid column!")
        }
    }
    
    func itemFor(row: Int, column: Int) -> String {
        let book = books[row]
        switch column {
        case 0: return book.title
        case 1: return book.author
        case 2: return String(book.avgAmazonRating)
        case 3: return book.isbn
        default: fatalError("Invalid column!")
        }
    }
}




var department = Department(name: "Engineering")
department.add(Person(name: "Joe", age: 30, yearsOfExperience: 6))
department.add(Person(name: "Karen", age: 40, yearsOfExperience: 18))
department.add(Person(name: "Fred", age: 50, yearsOfExperience: 20))
department.add(Person(name: "Testy Mc Testerson", age: 4057, yearsOfExperience: 50001))

printTable(department)
print("")
print("")



var bookCollection = BookCollection(title: "My Favorite Books")
bookCollection.add(Book(title: "Swift Programming: The Big Nerd Ranch Guide", author: "Matthew Mathias and John Gallagher", avgAmazonRating: 4.5, isbn: "978-0134610610"))
bookCollection.add(Book(title: "iOS Programming: The Big Nerd Ranch Guide", author: "Christian Keur", avgAmazonRating: 4.5, isbn: "978-0134682334"))
bookCollection.add(Book(title: "what if? Serious Scientific Answers to Absurd Hypothetical Questions", author: "Randall Munroe", avgAmazonRating: 4.5, isbn: "978-0544272996"))

printTable(bookCollection)
print("")
print("")
